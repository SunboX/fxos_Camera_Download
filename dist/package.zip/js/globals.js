'use strict';

// This array holds information about all the image files we
// know about. Each array element is an object that includes a
// filename and metadata.
var files = [];

var currentFileIndex = 0;
